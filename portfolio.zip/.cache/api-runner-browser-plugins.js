module.exports = [{
      plugin: require('D:/landing_page/portfolio/gatsby-browser.js'),
      options: {"plugins":[]},
    }]
