// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---src-templates-blog-js": () => import("D:\\landing_page\\portfolio\\src\\templates\\blog.js" /* webpackChunkName: "component---src-templates-blog-js" */),
  "component---src-templates-archive-js": () => import("D:\\landing_page\\portfolio\\src\\templates\\archive.js" /* webpackChunkName: "component---src-templates-archive-js" */),
  "component---cache-dev-404-page-js": () => import("D:\\landing_page\\portfolio\\.cache\\dev-404-page.js" /* webpackChunkName: "component---cache-dev-404-page-js" */),
  "component---src-pages-404-js": () => import("D:\\landing_page\\portfolio\\src\\pages\\404.js" /* webpackChunkName: "component---src-pages-404-js" */),
  "component---src-pages-contact-js": () => import("D:\\landing_page\\portfolio\\src\\pages\\contact.js" /* webpackChunkName: "component---src-pages-contact-js" */),
  "component---src-pages-index-js": () => import("D:\\landing_page\\portfolio\\src\\pages\\index.js" /* webpackChunkName: "component---src-pages-index-js" */),
  "component---src-pages-page-2-js": () => import("D:\\landing_page\\portfolio\\src\\pages\\page-2.js" /* webpackChunkName: "component---src-pages-page-2-js" */),
  "component---src-pages-thanks-js": () => import("D:\\landing_page\\portfolio\\src\\pages\\thanks.js" /* webpackChunkName: "component---src-pages-thanks-js" */)
}

