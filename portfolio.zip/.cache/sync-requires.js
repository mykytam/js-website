const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---src-templates-blog-js": hot(preferDefault(require("D:\\landing_page\\portfolio\\src\\templates\\blog.js"))),
  "component---src-templates-archive-js": hot(preferDefault(require("D:\\landing_page\\portfolio\\src\\templates\\archive.js"))),
  "component---cache-dev-404-page-js": hot(preferDefault(require("D:\\landing_page\\portfolio\\.cache\\dev-404-page.js"))),
  "component---src-pages-404-js": hot(preferDefault(require("D:\\landing_page\\portfolio\\src\\pages\\404.js"))),
  "component---src-pages-contact-js": hot(preferDefault(require("D:\\landing_page\\portfolio\\src\\pages\\contact.js"))),
  "component---src-pages-index-js": hot(preferDefault(require("D:\\landing_page\\portfolio\\src\\pages\\index.js"))),
  "component---src-pages-page-2-js": hot(preferDefault(require("D:\\landing_page\\portfolio\\src\\pages\\page-2.js"))),
  "component---src-pages-thanks-js": hot(preferDefault(require("D:\\landing_page\\portfolio\\src\\pages\\thanks.js")))
}

